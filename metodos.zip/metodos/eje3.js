var jugadores=("Lionel Messi","Angel Di maria","Dibu","Lautaro Martinez","Tagliafico");
jugadores.pop();
console.log(jugadores);