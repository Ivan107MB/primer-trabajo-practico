/*Do-while*/
n=10000
suma=0
do{
    var percio=parsefloat(prompt("valor del precio de producto"))
}while(suma<n)
    do{
        var valorIng=prompt("ingrese valores o t para terminar")
    }while(valorIng!=="t")
        var cont=0
        var arreglosVacio=[];
        do{
            var ValorIng=prompt("Ingrese frutas o t para terminar");
            var tipo="citrico"
            arregloVacio.uush(ValorIng)
        }while("")