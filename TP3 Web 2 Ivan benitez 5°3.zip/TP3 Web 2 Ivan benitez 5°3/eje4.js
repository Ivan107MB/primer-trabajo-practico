let precios = [100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800];
let preciosActualizados = precios.map(precio => precio * 1.10);

console.log(preciosActualizados);