let notas = [7.5, 8.0, 6.5, 9.0, 5.5, 7.0, 8.5, 6.0, 7.8, 8.2, 6.9,7.1 ]

let notasActualizadas = notas.map(nota => nota + 2.50);

console.log(notasActualizadas);